use Training_19Sep19_Pune
go
create schema [46008916]
create table [46008916].Patient
(
PatientID varchar(10) primary key,
PatientName varchar(20),
Age int,
PatientWeight int,
Gender char,
PAddress varchar(100),
MobileNo varchar(20),
Disease varchar(100),
DoctorID varchar(20) 
);

create table [46008916].Doctor
(
DoctorID varchar(20) primary key,
 DoctorName varchar(20),
 Department varchar(20)
 );
 create table [46008916].Lab
 (
 PatientID varchar(10),
 DoctorID varchar(20),
 TestDate date,
 TestType varchar(50),
 PatientType varchar(50)
 );
  
  create table [46008916].InPatient
  (
  PatientID varchar(