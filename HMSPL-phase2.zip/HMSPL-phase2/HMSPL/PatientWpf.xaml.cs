﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using HMSBAL;
using HMSEntity;
using Exceptions;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class PatientWpf : Window
    {
        HMSBal bal = null;
        public PatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtMobileNo.Text == string.Empty ||
                    txtGender.Text == string.Empty || txtAge.Text == string.Empty || txtWeight.Text == string.Empty || txtAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordAdded;
                    objPatient.PatientID = txtPatientId.Text;
                    objPatient.DoctorID = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.MobileNo = txtMobileNo.Text;

                    objPatient.Gender = txtGender.Text.ToString();


                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.Weight = float.Parse(txtWeight.Text);
                    objPatient.Address = txtAddress.Text;
                    objPatient.Disease = txtDisease.Text;



                    RecordAdded = HMSBal.AddPatientBAL(objPatient);
                    if (RecordAdded == true)
                    {
                        MessageBox.Show("Patient record added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be added.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtMobileNo.Text == string.Empty ||
                    txtGender.Text == string.Empty || txtAge.Text == string.Empty || txtWeight.Text == string.Empty || txtAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordUpdated;

                    objPatient.PatientID = txtPatientId.Text;
                    objPatient.DoctorID = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.MobileNo = txtMobileNo.Text;
                    objPatient.Gender = txtGender.Text;
                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.Weight = double.Parse(txtWeight.Text);
                    objPatient.Address = txtAddress.Text;
                    objPatient.Disease = txtDisease.Text;



                    RecordUpdated = HMSBal.UpdatePatientBAL(objPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("Patient record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be updated.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                //
                bool patientDeleted;
                //
                PatientId = txtPatientId.Text;
                //
                patientDeleted = HMSBal.DeletePatientBAL(PatientId);
                if (patientDeleted == true)
                {
                    MessageBox.Show("Patient record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be deleted.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                Patient objPatient;
                PatientId = txtPatientId.Text;
                objPatient = HMSBal.SearchPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txtDoctorId.Text = objPatient.DoctorID;
                    txtPatientName.Text = objPatient.PatientName;
                    txtMobileNo.Text = objPatient.MobileNo;
                    txtGender.Text= objPatient.Gender;
                    txtAge.Text = Convert.ToInt32(objPatient.Age).ToString();
                    txtWeight.Text = Convert.ToDouble(objPatient.Weight).ToString();
                    txtAddress.Text = objPatient.Address;
                    txtDisease.Text = objPatient.Disease;
                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    

    private void BtnSearchByDoctor_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string DoctorId;
            Patient objPatient;
            DoctorId = txtDoctorId.Text;
            objPatient = HMSBal.SearchPatientbyDoctorIDBAL(DoctorId);
            if (objPatient != null)
            {
                txtPatientId.Text = objPatient.PatientID;
                txtPatientName.Text = objPatient.PatientName;
                txtMobileNo.Text = objPatient.MobileNo;
                txtGender.Text = objPatient.Gender;
                txtAge.Text = Convert.ToInt32(objPatient.Age).ToString();
                txtWeight.Text = Convert.ToDouble(objPatient.Weight).ToString();
                txtAddress.Text = objPatient.Address;
                txtDisease.Text = objPatient.Disease;
            }

            else
            {
                MessageBox.Show("Patient record couldn't be found.");
            }

        }
        catch (HMSException ex)
        {
            MessageBox.Show(ex.Message);
        }

    }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtPatientId.Clear();
            txtDoctorId.Clear();
            txtPatientName.Clear();
            txtMobileNo.Clear();
            txtGender.SelectedIndex=-1;
            txtAge.Clear();
            txtWeight.Clear();
            txtAddress.Clear();
            txtDisease.Clear();
            dgPatient.DataContext = null;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                List<Employee> objEmployees = EmployeeBL.GetAllEmployeeBL();
                if (objEmployees != null)
                {
                    dgEmployees.ItemsSource = objEmployees;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HRDSException ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
    }
}
