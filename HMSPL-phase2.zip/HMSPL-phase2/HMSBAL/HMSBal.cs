﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntity;
using Exceptions;
using System.Text.RegularExpressions;
using System.Data;

namespace HMSBAL
{
    public class HMSBal
    {
        //private static bool ValidatePatient(Patient patient)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    bool validPatient = true;
        //    try
        //    {
        //        if (patient.PatientID == string.Empty)
        //        {
        //            sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
        //            validPatient = false;
        //        }
        //        if (patient.PatientName == string.Empty)
        //        {
        //            sb.Append(Environment.NewLine + "Patient Name is Required");
        //            validPatient = false;
        //        }
        //        if (patient.Gender == "Select")
        //        {
        //            sb.Append(Environment.NewLine + "Gender Id is Required");
        //            validPatient = false;
        //        }
        //        if (patient.MobileNo.Length < 10)
        //        {
        //            sb.Append(Environment.NewLine + "Phone Number should have 10 digits");
        //            validPatient = false;
        //        }
        //        else if (!Regex.IsMatch(patient.MobileNo, "[6-9][0-9]{9}"))
        //        {
        //            sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
        //            validPatient = false;
        //        }
        //        if (patient.DoctorID == "Select")
        //        {
        //            sb.Append(Environment.NewLine + "Doctor Id is Required");
        //            validPatient = false;
        //        }
        //        if (validPatient == false)
        //            throw new Exceptions.HMSException(sb.ToString());
        //    }
        //    catch (Exceptions.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return validPatient;
        //}
        //public static int AddPatientBLL(Patient newPatient)
        //{
        //    int patientAdded = 0;
        //    try
        //    {
        //        if (ValidatePatient(newPatient))
        //        {
        //            patientAdded = HMSDal.AddPatientDAL(newPatient);
        //        }
        //    }
        //    catch (Exceptions.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAdded;
        //}

        //public static DataTable GetAllPatientsBLL()
        //{
        //    DataTable dtPatient = null;
        //    try
        //    {
        //        dtPatient = HMSDal.GetAllPatientsDAL();
        //    }
        //    catch (Exceptions.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dtPatient;
        //}

        //public static int DeletePatientBLL(string deletePatientID)
        //{
        //    int patientDeleted = 0;
        //    try
        //    {
        //        if (deletePatientID != null)
        //        {
        //            patientDeleted = HMSDal.DeletePatientDAL(deletePatientID);
        //        }
        //        else
        //        {
        //            throw new Exceptions.HMSException("Invalid Patient ID");
        //        }
        //    }
        //    catch (Exceptions.HMSException)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientDeleted;
        //}

        //public static Patient SearchPatientBLL(string searchPatientID)
        //{
        //    Patient searchPatient = null;
        //    try
        //    {
        //        searchPatient = HMSDal.SearchPatientDAL(searchPatientID);
        //    }
        //    catch (Exceptions.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatient;
        //}

        //public static DataSet SearchPatientByDoctorBLL(string searchPatientID)
        //{
        //    DataSet dataSet = new DataSet();// searchPatient = null;
        //    try
        //    {
        //        dataSet = HMSDal.SearchPatientByDoctorDAL(searchPatientID);
        //    }
        //    catch (Exceptions.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dataSet;
        //}

        //public static int UpdatePatientBLL(Patient updatePatient)
        //{
        //    int patientUpdated = 0;
        //    try
        //    {
        //        if (ValidatePatient(updatePatient))
        //        {
        //            //HospitalDAL patientDAL = new HospitalDAL();
        //            patientUpdated = HMSDal.UpdatePatientDAL(updatePatient);
        //        }
        //    }
        //    catch (Exceptions.HMSException)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return patientUpdated;
        //}
  //  }
//}























































private static bool ValidatePatient(Patient patient)
{
    StringBuilder sb = new StringBuilder();
    bool validPatient = true;
    if (patient.PatientID == string.Empty)
    {
        validPatient = false;
        sb.Append(Environment.NewLine
            + "Patient can't  be empty");
    }
    if (patient.DoctorID == string.Empty)
    {
        validPatient = false;
        sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
    }
    if (patient.PatientName == string.Empty)
    {
        validPatient = false;
        sb.Append(Environment.NewLine + "Patient name should start with Capital.");
    }
    if (patient.MobileNo.Length < 0)
    {
        validPatient = false;
        sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
    }
    else if (!Regex.IsMatch(patient.MobileNo, "[6-9][0-9]{9}"))
    {
        sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
        validPatient = false;
    }
    if (validPatient == false)
    {
        throw new HMSException(sb.ToString());
    }
    return validPatient;

}
public static bool AddPatientBAL(Patient patient)
{
    bool patientAdded = false;
    try
    {
        if (ValidatePatient(patient))
        {
            HMSDal patientDAL = new HMSDal();
            patientAdded = patientDAL.AddPatientDAL(patient);
            return patientAdded;
        }
    }
    catch (HMSException ex)
    {
        throw ex;
    }
    catch (Exception ex)
    {
        throw ex;
    }
    return patientAdded;
}

public static bool UpdatePatientBAL(Patient patient)
{
    bool patientUpdated = false;
    try
    {
        if (ValidatePatient(patient))
        {
            HMSDal patientDAL = new HMSDal();
            patientUpdated = patientDAL.UpdatePatientDAL(patient);
            return patientUpdated;
        }
    }
    catch (HMSException ex)
    {
        throw ex;
    }
    catch (Exception ex)
    {
        throw ex;
    }
    return patientUpdated;
}

public static bool DeletePatientBAL(string PatientId)
{

    bool PatientDeleted = false;
    try
    {
        if (PatientId != null)
        {
            HMSDal patientDAL = new HMSDal();

            PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
        }
        else
        {
            throw new Exceptions.HMSException("Invalid OutPatient ID");
        }
    }
    catch (HMSException ex)
    {
        throw ex;
    }
    catch (Exception ex)
    {
        throw ex;
    }
    return PatientDeleted;
}

public static Patient SearchPatientbyPatientIDBAL(string patientId)
{
    Patient patient = null;

    try
    {
        if (patientId != null)
        {
            HMSDal patientDAL = new HMSDal();
            patient = patientDAL.SearchPatientbyPatientIDDAL(patientId);
        }
        else
        {
            throw new HMSException("Patient Id is Required.");
        }
    }
    catch (HMSException ex)
    {
        throw ex;
    }
    catch (Exception ex)
    {
        throw ex;
    }
    return patient;
}
public static Patient SearchPatientbyDoctorIDBAL(string doctorId)
{
    Patient patient = null;

    try
    {
        if (doctorId != null)
        {
            HMSDal patientDAL = new HMSDal();
            patient = patientDAL.SearchPatientbyDoctorIDDAL(doctorId);
        }
        else
        {
            throw new HMSException("Doctor Id is Required.");
        }
    }
    catch (HMSException ex)
    {
        throw ex;
    }
    catch (Exception ex)
    {
        throw ex;
    }
    return patient;
}
        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                HMSDal patient = new HMSDal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

    }
}
