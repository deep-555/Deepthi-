﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HMSEntity;
using Exceptions;

namespace HMSDAL
{
    public class HMSDal
    {
        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].InsertPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", objPatient.Weight);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", objPatient.Address);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Disease);
                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].UpdatePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", objPatient.Weight);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", objPatient.Address);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Gender);
                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(string patientID)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].DeletePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

                //
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientbyPatientIDDAL(string PatientId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].SelectPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                //
                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_Weight.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                objSqlParam_PatientID.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.Weight = Convert.ToDouble(objSqlParam_Weight.Value);
                objPatient.Address = objSqlParam_Address.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }
        public Patient SearchPatientbyDoctorIDDAL(string DoctorId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].SelectPatientByDoctor", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                //
                objSqlParam_PatientID.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Input;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_Weight.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                objSqlParam_DoctorID.Value = DoctorId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.Weight = Convert.ToDouble(objSqlParam_Weight.Value);
                objPatient.Address = objSqlParam_Address.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> Patients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.PatientID = objDR[1] as string;
                    objPatient.DoctorID = objDR[2] as string;
                    objPatient.PatientName = objDR[3] as string ;
                    objPatient.Gender = objDR[4] as string;
                    objPatient.MobileNo = objDR[5] as string;
                    objPatient.Age = Convert.ToInt32(objDR[6]);
                    objPatient.Weight=Convert.ToDouble(objDR[7]);
                    objPatient.Address = objDR[8] as string;
                    objPatient.Disease = objDR[9] as string;



                    Patients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Patients;
        }
























        //public static SqlCommand CreateCommand()
        //{
        //    SqlCommand cmd = null;
        //    try
        //    {
        //        SqlConnection con = new SqlConnection();


        //        con.ConnectionString = ConfigurationManager.ConnectionStrings["HMSConnection"].ConnectionString;
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Connection = con;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return cmd;
        //}

        //public static int AddPatientDAL(Patient newPatient)
        //{
        //    int patientAdded = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].InsertPatient";
        //        cmdobj.Parameters.AddWithValue("@PatientID", newPatient.PatientID);
        //        cmdobj.Parameters.AddWithValue("@PatientName", newPatient.PatientName);
        //        cmdobj.Parameters.AddWithValue("@Age", newPatient.Age);
        //        cmdobj.Parameters.AddWithValue("@PatientWeight", newPatient.Weight);
        //        cmdobj.Parameters.AddWithValue("@Gender", newPatient.Gender);
        //        cmdobj.Parameters.AddWithValue("@PAddress", newPatient.Address);
        //        cmdobj.Parameters.AddWithValue("@MobileNo", newPatient.MobileNo);
        //        cmdobj.Parameters.AddWithValue("@Disease", newPatient.Disease);
        //        cmdobj.Parameters.AddWithValue("@DoctorID", newPatient.DoctorID);

        //        cmdobj.Connection.Open();
        //        patientAdded = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAdded;
        //}

        //public static DataTable GetAllPatientsDAL()
        //{
        //    DataTable dtPatient = new DataTable();
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].ListPatient";

        //        cmdobj.Connection.Open();
        //        SqlDataReader dr = cmdobj.ExecuteReader();
        //        dtPatient.Load(dr);
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dtPatient;
        //}

        //public static int DeletePatientDAL(string deletepatientID)
        //{
        //    int patientDeleted = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].DeletePatient";
        //        cmdobj.Parameters.AddWithValue("@PatientID", deletepatientID);
        //        cmdobj.Connection.Open();
        //        patientDeleted = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientDeleted;
        //}

        //public static Patient SearchPatientDAL(string searchPatientID)
        //{
        //    Patient searchPatient = null;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].SelectPatient";
        //        cmdobj.Parameters.AddWithValue("@PatientID", searchPatientID);
        //        cmdobj.Connection.Open();
        //        SqlDataReader drPatient = cmdobj.ExecuteReader();
        //        if (drPatient.HasRows)
        //        {
        //            searchPatient = new Patient();
        //            drPatient.Read();
        //            //using column name, retrieving values
        //            searchPatient.PatientID = drPatient["PatientID"].ToString();
        //            searchPatient.PatientName = drPatient["PatientName"].ToString();
        //            searchPatient.Age = Convert.ToInt32(drPatient["Age"]);
        //            searchPatient.Weight = Convert.ToInt32(drPatient["PatientWeight"]);
        //            searchPatient.Gender = drPatient["Gender"].ToString();
        //            searchPatient.Address = drPatient["PAddress"].ToString();
        //            searchPatient.MobileNo = drPatient["MobileNo"].ToString();
        //            searchPatient.Disease = drPatient["Disease"].ToString();
        //            searchPatient.DoctorID = drPatient["DoctorID"].ToString();
        //        }
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatient;
        //}

        //public static DataSet SearchPatientByDoctorDAL(string searchPatientByDoctorID)
        //{
        //    DataSet dataSet = new DataSet();
        //    //Patient searchPatient = null;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].SelectPatientByDoctor";
        //        cmdobj.Parameters.AddWithValue("@DoctorID", searchPatientByDoctorID);
        //        cmdobj.Connection.Open();
        //        SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
        //        adapter.Fill(dataSet, "Patient");
        //        cmdobj.Connection.Close();
        //        //SqlDataReader drPatient = cmdobj.ExecuteReader();
        //        //if (drPatient.HasRows)
        //        //{
        //        //    searchPatient = new Patient();
        //        //    drPatient.Read();
        //        //    //using column name, retrieving values
        //        //    searchPatient.PatientId = drPatient["PatientID"].ToString();
        //        //    searchPatient.PatientName = drPatient["Name"].ToString();
        //        //    searchPatient.Age = Convert.ToInt32(drPatient["Age"]);
        //        //    searchPatient.Weight = Convert.ToInt32(drPatient["Weight"]);
        //        //    searchPatient.Gender = drPatient["Gender"].ToString();
        //        //    searchPatient.Address = drPatient["Address"].ToString();
        //        //    searchPatient.PhoneNo = drPatient["PhoneNo"].ToString();
        //        //    searchPatient.Disease = drPatient["Disease"].ToString();
        //        //    searchPatient.DoctorId = drPatient["DoctorId"].ToString();
        //        //}
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dataSet;
        //}

        //public static int UpdatePatientDAL(Patient updatePatient)
        //{
        //    int patientUpdated = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "[46008916].UpdatePatient";
        //        cmdobj.Parameters.AddWithValue("@PatientID", updatePatient.PatientID);
        //        cmdobj.Parameters.AddWithValue("@PatientName", updatePatient.PatientName);
        //        cmdobj.Parameters.AddWithValue("@Age", updatePatient.Age);
        //        cmdobj.Parameters.AddWithValue("@PatientWeight", updatePatient.Weight);
        //        cmdobj.Parameters.AddWithValue("@Gender", updatePatient.Gender);
        //        cmdobj.Parameters.AddWithValue("@PAddress", updatePatient.Address);
        //        cmdobj.Parameters.AddWithValue("@MobileNo", updatePatient.MobileNo);
        //        cmdobj.Parameters.AddWithValue("@Disease", updatePatient.Disease);
        //        cmdobj.Parameters.AddWithValue("@DoctorID", updatePatient.DoctorID);
        //        cmdobj.Connection.Open();
        //        patientUpdated = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientUpdated;
        //}




































        //public static int AddPatientAppointmentDAL(Appointment newAppointment)
        //{
        //    int appointmentAdded = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_InsertAppointment";
        //        cmdobj.Parameters.AddWithValue("@aid", newAppointment.AppointmentId);
        //        cmdobj.Parameters.AddWithValue("@pid", newAppointment.PatientId);
        //        cmdobj.Parameters.AddWithValue("@dname", newAppointment.DoctorName);
        //        cmdobj.Parameters.AddWithValue("@roomno", newAppointment.RoomNo);
        //        cmdobj.Parameters.AddWithValue("@dateofvisit", newAppointment.DateOfVisit);
        //        cmdobj.Parameters.AddWithValue("@admissiondate", newAppointment.AdmissionDate);
        //        cmdobj.Parameters.AddWithValue("@dischargedate", newAppointment.DischargeDate);
        //        cmdobj.Parameters.AddWithValue("@remarks", newAppointment.Remarks);
        //        cmdobj.Connection.Open();
        //        appointmentAdded = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return appointmentAdded;
        //}

        //public static DataTable GetAllPatientsAppointmentDAL()
        //{
        //    DataTable dtAppointment = new DataTable();
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_GetAllAppointment";

        //        cmdobj.Connection.Open();
        //        SqlDataReader dr = cmdobj.ExecuteReader();
        //        dtAppointment.Load(dr);
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dtAppointment;
        //}

        //public static int DeletePatientAppointmentDAL(string deletePatientAppointmentID)
        //{
        //    int patientAppointment = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_delAppointment";
        //        cmdobj.Parameters.AddWithValue("@pid", deletePatientAppointmentID);
        //        cmdobj.Connection.Open();
        //        patientAppointment = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAppointment;
        //}

        //public static Appointment SearchPatientDoctorDAL(string searchPatientDOC)
        //{
        //    Appointment searchPatientdoc = null;
        //    try
        //    {
        //        for (int i = 0; i < patientList.Count; i++)
        //        {
        //            Appointment patient = appointmentList[i];
        //            if (patient.DoctorName == searchPatientDOC)
        //            {
        //                searchPatientdoc = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdoc;
        //}

        //public static Appointment SearchPatientDOVDAL(DateTime searchPatientDOV)
        //{
        //    Appointment searchPatientdov = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.DateOfVisit == searchPatientDOV)
        //            {
        //                searchPatientdov = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdov;
        //}

        //public static Appointment SearchPatientDOADAL(DateTime searchPatientDOA)
        //{
        //    Appointment searchPatientdoa = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.AdmissionDate == searchPatientDOA)
        //            {
        //                searchPatientdoa = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdoa;
        //}

        //public static Appointment SearchPatientDODDAL(DateTime searchPatientDOD)
        //{
        //    Appointment searchPatientdod = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.DischargeDate == searchPatientDOD)
        //            {
        //                searchPatientdod = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdod;
        //}

        //        public static int AddPatientBillDAL(Bill newBill)
        //        {
        //            int billAdded = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916]InsertBill";
        //                cmdobj.Parameters.AddWithValue("@BillID", newBill.BillID);
        //                cmdobj.Parameters.AddWithValue("@PatientID", newBill.PatientID);
        //                cmdobj.Parameters.AddWithValue("@PatientType", newBill.PatientType);
        //                cmdobj.Parameters.AddWithValue("@DoctorID", newBill.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@DoctorFee", newBill.DoctorFees);
        //                cmdobj.Parameters.AddWithValue("@RoomCharge", newBill.RoomCharges);
        //                cmdobj.Parameters.AddWithValue("@OperationCharges", newBill.OperationCharges);
        //                cmdobj.Parameters.AddWithValue("@MedicineFee", newBill.MedicineFees);
        //                cmdobj.Parameters.AddWithValue("@TotalDays", newBill.TotalDays);
        //                cmdobj.Parameters.AddWithValue("@LabFee", newBill.LabFees);
        //                cmdobj.Parameters.AddWithValue("@TotalAmount", newBill.TotalAmount);
        //                cmdobj.Connection.Open();
        //                billAdded = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw new Exceptions.HMSException(ex.Message);
        //            }
        //            return billAdded;
        //        }

        //        public static DataTable GetAllPatientBillDAL()
        //        {
        //            DataTable dtBill = new DataTable();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetAllBill";
        //                cmdobj.Connection.Open();
        //                SqlDataReader dr = cmdobj.ExecuteReader();
        //                dtBill.Load(dr);
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dtBill;
        //        }

        //        public static Bill SearchBillByIdDAL(string searchBillID)
        //        {
        //            Bill searchBill = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916].SelectBill";
        //                cmdobj.Parameters.AddWithValue("@billid", searchBillID);
        //                cmdobj.Connection.Open();
        //                SqlDataReader drBill = cmdobj.ExecuteReader();
        //                if (drBill.HasRows)
        //                {
        //                    searchBill = new Bill();
        //                    drBill.Read();
        //                    //using column name, retrieving values
        //                    searchBill.BillID = drBill["BillID"].ToString();
        //                    searchBill.PatientID = drBill["PatientID"].ToString();
        //                    searchBill.PatientType = drBill["PatientType"].ToString();
        //                    searchBill.DoctorID = drBill["DoctorID"].ToString();
        //                    searchBill.DoctorFees = Convert.ToDouble(drBill["DoctorFee"]);
        //                    searchBill.RoomCharges = Convert.ToDouble(drBill["RoomCharge"]);
        //                    searchBill.OperationCharges = Convert.ToDouble(drBill["OperationCharges"]);
        //                    searchBill.MedicineFees = Convert.ToDouble(drBill["MedicineFee"]);
        //                    searchBill.TotalDays = Convert.ToInt32(drBill["TotalDays"]);
        //                    searchBill.LabFees = Convert.ToDouble(drBill["LabFee"]);
        //                    searchBill.TotalAmount = Convert.ToDouble(drBill["TotalAmount"]);
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return searchBill;
        //        }

        //        public static int UpdateBillByIdDAL(Bill updateBill)
        //        {
        //            int patientUpdated = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916].UpdateBill";
        //                cmdobj.Parameters.AddWithValue("@BillID", updateBill.BillID);
        //                cmdobj.Parameters.AddWithValue("@PatientID", updateBill.PatientID);
        //                cmdobj.Parameters.AddWithValue("@PatientType", updateBill.PatientType);
        //                cmdobj.Parameters.AddWithValue("@DoctorID", updateBill.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@DoctorFee", updateBill.DoctorFees);
        //                cmdobj.Parameters.AddWithValue("@RoomCharges", updateBill.RoomCharges);
        //                cmdobj.Parameters.AddWithValue("@OperationCharges", updateBill.OperationCharges);
        //                cmdobj.Parameters.AddWithValue("@Medicinefee", updateBill.MedicineFees);
        //                cmdobj.Parameters.AddWithValue("@TotalDays", updateBill.TotalDays);
        //                cmdobj.Parameters.AddWithValue("@LabFee", updateBill.LabFees);
        //                cmdobj.Parameters.AddWithValue("@TotalAmount", updateBill.TotalAmount);
        //                cmdobj.Connection.Open();
        //                patientUpdated = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return patientUpdated;
        //        }

        //        public static int DeletePatientBillDAL(string deletePatientBillID)
        //        {
        //            int patientBill = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916].DeleteBill";
        //                cmdobj.Parameters.AddWithValue("@BillID", deletePatientBillID);
        //                cmdobj.Connection.Open();
        //                patientBill = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return patientBill;
        //        }

        //        public static int AddPatientLabReportDAL(Lab newLabReport)
        //        {
        //            int labReportAdded = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916].InsertLab";
        //                cmdobj.Parameters.AddWithValue("@LabNo", newLabReport.LabNo);
        //                cmdobj.Parameters.AddWithValue("@PatientID", newLabReport.PatientID);
        //                cmdobj.Parameters.AddWithValue("@DoctorID", newLabReport.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@TestDate", newLabReport.TestDate);
        //                cmdobj.Parameters.AddWithValue("@TestType", newLabReport.TestType);
        //                cmdobj.Parameters.AddWithValue("@PatientType", newLabReport.PatientType);
        //                cmdobj.Connection.Open();
        //                labReportAdded = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (Exception ex)
        //            {
        //                throw new Exceptions.HMSException(ex.Message);
        //            }
        //            return labReportAdded;
        //        }

        //        public static DataTable GetAllPatientLabReportDAL()
        //        {
        //            DataTable dtLabReport = new DataTable();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "[46008916].ListLab";
        //                cmdobj.Connection.Open();
        //                SqlDataReader dr = cmdobj.ExecuteReader();
        //                dtLabReport.Load(dr);
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dtLabReport;
        //        }

        //        public static Lab SearchReportByIdDAL(string searchReportID)
        //        {
        //            Lab searchLabReport = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_searchLabReportById";
        //                cmdobj.Parameters.AddWithValue("@llabId", searchReportID);
        //                cmdobj.Connection.Open();
        //                SqlDataReader drLabReport = cmdobj.ExecuteReader();
        //                if (drLabReport.HasRows)
        //                {
        //                    searchLabReport = new Lab();
        //                    drLabReport.Read();
        //                    //using column name, retrieving values
        //                    searchLabReport.LabNo = drLabReport["LabId"].ToString();
        //                    searchLabReport.PatientID = drLabReport["PId"].ToString();
        //                    searchLabReport.DoctorID = drLabReport["DoctorId"].ToString();
        //                    searchLabReport.TestDate = Convert.ToDateTime(drLabReport["TestDate"]);
        //                    searchLabReport.TestType = drLabReport["TestType"].ToString();
        //                    searchLabReport.PatientType = drLabReport["PatientType"].ToString();
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return searchLabReport;
        //        }

        //        public static int DeletePatientLabReportDAL(string deletePatientLabReportID)
        //        {
        //            int labReport = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_delLabReport";
        //                cmdobj.Parameters.AddWithValue("@llabid", deletePatientLabReportID);
        //                cmdobj.Connection.Open();
        //                labReport = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return labReport;
        //        }

        //        public static int UpdateLabReportByIdDAL(Lab updateLabReport)
        //        {
        //            int patientUpdated = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_UpdateLabReportByID";
        //                cmdobj.Parameters.AddWithValue("@llabId", updateLabReport.LabNo);
        //                cmdobj.Parameters.AddWithValue("@lpId", updateLabReport.PatientID);
        //                cmdobj.Parameters.AddWithValue("@ldId", updateLabReport.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@lTestDate", updateLabReport.TestDate);
        //                cmdobj.Parameters.AddWithValue("@lTestType", updateLabReport.TestType);
        //                cmdobj.Parameters.AddWithValue("@lpType", updateLabReport.PatientType);
        //                cmdobj.Connection.Open();
        //                patientUpdated = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return patientUpdated;
        //        }

        //        public static int AddInPatientDAL(InPatient newInPatient)
        //        {
        //            int inPatientAdded = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_insertInPatient";
        //                cmdobj.Parameters.AddWithValue("@pId", newInPatient.PatientID);
        //                cmdobj.Parameters.AddWithValue("@roomno", newInPatient.RoomNo);
        //                cmdobj.Parameters.AddWithValue("@dId", newInPatient.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@admissiondate", newInPatient.AdmissionDate);
        //                cmdobj.Parameters.AddWithValue("@dischargedate", newInPatient.DischargeDate);
        //                cmdobj.Parameters.AddWithValue("@labId", newInPatient.LabNo);
        //                cmdobj.Parameters.AddWithValue("@amount", newInPatient.Amount);
        //                cmdobj.Connection.Open();
        //                inPatientAdded = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return inPatientAdded;
        //        }

        //        public static DataTable GetAllInPatientsDAL()
        //        {
        //            DataTable dtInPatient = new DataTable();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetAllInPatients";

        //                cmdobj.Connection.Open();
        //                SqlDataReader dr = cmdobj.ExecuteReader();
        //                dtInPatient.Load(dr);
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dtInPatient;
        //        }

        //        public static InPatient SearchInPatientDAL(string searchPatientID)
        //        {
        //            InPatient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetInPatientById";
        //                cmdobj.Parameters.AddWithValue("@pId", searchPatientID);
        //                cmdobj.Connection.Open();
        //                SqlDataReader drPatient = cmdobj.ExecuteReader();
        //                if (drPatient.HasRows)
        //                {
        //                    searchPatient = new InPatient();
        //                    drPatient.Read();
        //                    //using column name, retrieving values
        //                    searchPatient.PatientID = drPatient["PatientID"].ToString();
        //                    searchPatient.RoomNo = drPatient["RoomNo"].ToString();
        //                    searchPatient.DoctorID = drPatient["DoctorId"].ToString();
        //                    searchPatient.AdmissionDate = Convert.ToDateTime(drPatient["AdmissionDate"]);
        //                    searchPatient.DischargeDate = Convert.ToDateTime(drPatient["DischargeDate"]);
        //                    searchPatient.LabNo = drPatient["LabId"].ToString();
        //                    searchPatient.Amount = Convert.ToInt32(drPatient["AmountPerDay"]);
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return searchPatient;
        //        }

        //        public static int UpdateInPatientDAL(InPatient updateInPatient)
        //        {
        //            int inPatientUpdated = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_UpdateInPatientByID";
        //                cmdobj.Parameters.AddWithValue("@pId", updateInPatient.PatientID);
        //                cmdobj.Parameters.AddWithValue("@roomno", updateInPatient.RoomNo);
        //                cmdobj.Parameters.AddWithValue("@dId", updateInPatient.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@admissiondate", updateInPatient.AdmissionDate);
        //                cmdobj.Parameters.AddWithValue("@dischargedate", updateInPatient.DischargeDate);
        //                cmdobj.Parameters.AddWithValue("@labId", updateInPatient.LabNo);
        //                cmdobj.Parameters.AddWithValue("@amount", updateInPatient.Amount);
        //                cmdobj.Connection.Open();
        //                inPatientUpdated = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return inPatientUpdated;
        //        }

        //        public static int DeleteInPatientDAL(string deleteInPatientID)
        //        {
        //            int inPatientDeleted = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_delInPatientById";
        //                cmdobj.Parameters.AddWithValue("@pId", deleteInPatientID);
        //                cmdobj.Connection.Open();
        //                inPatientDeleted = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return inPatientDeleted;
        //        }

        //        public static DataSet SearchInPatientByDoctorDAL(string searchInPatientByDoctorID)
        //        {
        //            DataSet dataSet = new DataSet();
        //            //Patient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetInPatientByDoctorId";
        //                cmdobj.Parameters.AddWithValue("@dId", searchInPatientByDoctorID);
        //                cmdobj.Connection.Open();
        //                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
        //                adapter.Fill(dataSet, "InPatient");
        //                cmdobj.Connection.Close();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dataSet;
        //        }

        //        public static DataSet SearchInPatientByRoomDAL(string searchInPatientByRoomID)
        //        {
        //            DataSet dataSet = new DataSet();
        //            //Patient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetInPatientByRoomId";
        //                cmdobj.Parameters.AddWithValue("@roomId", searchInPatientByRoomID);
        //                cmdobj.Connection.Open();
        //                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
        //                adapter.Fill(dataSet, "InPatient");
        //                cmdobj.Connection.Close();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dataSet;
        //        }

        //        public static int AddOutPatientDAL(OutPatient newOutPatient)
        //        {
        //            int inPatientAdded = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_insertOutPatient";
        //                cmdobj.Parameters.AddWithValue("@pId", newOutPatient.PatientID);
        //                cmdobj.Parameters.AddWithValue("@treatmentdate", newOutPatient.TreatmentDate);
        //                cmdobj.Parameters.AddWithValue("@dId", newOutPatient.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@labId", newOutPatient.LabNo);
        //                cmdobj.Connection.Open();
        //                inPatientAdded = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return inPatientAdded;
        //        }

        //        public static DataTable GetAllOutPatientsDAL()
        //        {
        //            DataTable dtOutPatient = new DataTable();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetAllOutPatients";

        //                cmdobj.Connection.Open();
        //                SqlDataReader dr = cmdobj.ExecuteReader();
        //                dtOutPatient.Load(dr);
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dtOutPatient;
        //        }

        //        public static OutPatient SearchOutPatientDAL(string searchPatientID)
        //        {
        //            OutPatient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetOutPatientById";
        //                cmdobj.Parameters.AddWithValue("@pId", searchPatientID);
        //                cmdobj.Connection.Open();
        //                SqlDataReader drPatient = cmdobj.ExecuteReader();
        //                if (drPatient.HasRows)
        //                {
        //                    searchPatient = new OutPatient();
        //                    drPatient.Read();
        //                    //using column name, retrieving values
        //                    searchPatient.PatientID = drPatient["Pid"].ToString();
        //                    searchPatient.TreatmentDate = Convert.ToDateTime(drPatient["TreatmentDate"]);
        //                    searchPatient.DoctorID = drPatient["DoctorId"].ToString();
        //                    searchPatient.LabNo = drPatient["LabId"].ToString();
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return searchPatient;
        //        }

        //        public static int DeleteOutPatientDAL(string deleteInPatientID)
        //        {
        //            int outPatientDeleted = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_delOutPatientById";
        //                cmdobj.Parameters.AddWithValue("@pId", deleteInPatientID);
        //                cmdobj.Connection.Open();
        //                outPatientDeleted = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return outPatientDeleted;
        //        }

        //        public static int UpdateOutPatientDAL(OutPatient updateOutPatient)
        //        {
        //            int outPatientUpdated = 0;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_UpdateOutPatientByID";
        //                cmdobj.Parameters.AddWithValue("@pId", updateOutPatient.PatientID);
        //                cmdobj.Parameters.AddWithValue("@treatmentdate", updateOutPatient.TreatmentDate);
        //                cmdobj.Parameters.AddWithValue("@dId", updateOutPatient.DoctorID);
        //                cmdobj.Parameters.AddWithValue("@labId", updateOutPatient.LabNo);
        //                cmdobj.Connection.Open();
        //                outPatientUpdated = cmdobj.ExecuteNonQuery();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return outPatientUpdated;
        //        }

        //        public static DataSet SearchOutPatientByDoctorDAL(string searchOutPatientByDoctorID)
        //        {
        //            DataSet dataSet = new DataSet();
        //            //Patient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetOutPatientByDoctorId";
        //                cmdobj.Parameters.AddWithValue("@dId", searchOutPatientByDoctorID);
        //                cmdobj.Connection.Open();
        //                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
        //                adapter.Fill(dataSet, "OutPatient");
        //                cmdobj.Connection.Close();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dataSet;
        //        }

        //        public static DataSet SearchOutPatientByLabDAL(string searchOutPatientByLabID)
        //        {
        //            DataSet dataSet = new DataSet();
        //            //Patient searchPatient = null;
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetOutPatientByLabId";
        //                cmdobj.Parameters.AddWithValue("@labId", searchOutPatientByLabID);
        //                cmdobj.Connection.Open();
        //                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
        //                adapter.Fill(dataSet, "OutPatient");
        //                cmdobj.Connection.Close();
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return dataSet;
        //        }



        //        public static List<string> GetDoctorIdsDAL()
        //        {
        //            List<string> listOfIds = new List<string>();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetDoctorIDs";
        //                cmdobj.Connection.Open();
        //                SqlDataReader drIds = cmdobj.ExecuteReader();
        //                listOfIds.Add("Select");
        //                if (drIds.HasRows)
        //                {
        //                    while (drIds.Read())
        //                    {
        //                        listOfIds.Add(drIds["DoctorId"].ToString());
        //                    }
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return listOfIds;
        //        }

        //        public static List<string> GetPatientIdsDAL()
        //        {
        //            List<string> listOfIds = new List<string>();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetPatientIDs";
        //                cmdobj.Connection.Open();
        //                SqlDataReader drIds = cmdobj.ExecuteReader();
        //                listOfIds.Add("Select");
        //                if (drIds.HasRows)
        //                {
        //                    while (drIds.Read())
        //                    {
        //                        listOfIds.Add(drIds["PatientId"].ToString());
        //                    }
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return listOfIds;
        //        }

        //        public static List<string> GetLabIdsDAL()
        //        {
        //            List<string> listOfIds = new List<string>();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetLabIDs";
        //                cmdobj.Connection.Open();
        //                SqlDataReader drIds = cmdobj.ExecuteReader();
        //                listOfIds.Add("Select");
        //                if (drIds.HasRows)
        //                {
        //                    while (drIds.Read())
        //                    {
        //                        listOfIds.Add(drIds["LabId"].ToString());
        //                    }
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return listOfIds;
        //        }

        //        public static List<string> GetRoomIdsDAL()
        //        {
        //            List<string> listOfIds = new List<string>();
        //            try
        //            {
        //                SqlCommand cmdobj = CreateCommand();
        //                cmdobj.CommandText = "prc_GetRoomIDs";
        //                cmdobj.Connection.Open();
        //                SqlDataReader drIds = cmdobj.ExecuteReader();
        //                listOfIds.Add("Select");
        //                if (drIds.HasRows)
        //                {
        //                    while (drIds.Read())
        //                    {
        //                        listOfIds.Add(drIds["RoomNo"].ToString());
        //                    }
        //                }
        //                cmdobj.Connection.Close();
        //            }
        //            catch (SqlException ex)
        //            {
        //                throw ex;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw ex;
        //            }
        //            return listOfIds;
        //        }
    }
}
