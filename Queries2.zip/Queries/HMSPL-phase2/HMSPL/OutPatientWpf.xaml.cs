﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBAL;
using HMSEntity;
using Exceptions;
using System.Data;
namespace HMSPL
{
    /// <summary>
    /// Interaction logic for OutPatient.xaml
    /// </summary>
    public partial class OutPatientWpf : Window
    {
        HMSBal bal = null;
        public OutPatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient patient = new OutPatient();
                if (txtPatientId.Text == string.Empty || txtDate.Text == string.Empty || txtDoctorId.Text == string.Empty ||  
                   txtLabNo.Text == string.Empty )
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool OutpatientAdded;
                    patient.PatientID = txtPatientId.Text;
                    patient.TreatmentDate = Convert.ToDateTime(txtDate.Text);
                    patient.DoctorID = txtDoctorId.Text;                  
                    patient.LabNo = txtLabNo.Text;
                    
                    OutpatientAdded = HMSBal.AddOutPatientBAL(patient);
                    if (OutpatientAdded == true)
                    {
                        MessageBox.Show("OutPatient added successfully");
                    }
                    else
                    {
                        MessageBox.Show("OutPatient not added successfully");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient patient = new OutPatient();
                if (txtPatientId.Text == string.Empty || txtDate.Text == string.Empty || txtDoctorId.Text == string.Empty ||
                   txtLabNo.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool OutpatientUpdatedd;
                    patient.PatientID = txtPatientId.Text;
                    patient.TreatmentDate = Convert.ToDateTime(txtDate.Text);
                    patient.DoctorID = txtDoctorId.Text;
                    patient.LabNo = txtLabNo.Text;

                    OutpatientUpdatedd = HMSBal.UpdateOutPatientBAL(patient);
                    if (OutpatientUpdatedd == true)
                    {
                        MessageBox.Show("OutPatient updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("OutPatient couldn't be updated ");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string patientID;
            OutPatient patient = new OutPatient();
            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientID = txtPatientId.Text;
                    //
                    patientDeleted = HMSBal.DeleteInPatientBAL(patientID);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                OutPatient objPatient;
                PatientId = txtPatientId.Text;
                objPatient = HMSBal.SearchOutPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txtDate.Text = Convert.ToDateTime(objPatient.TreatmentDate).ToString();
                    txtDoctorId.Text = objPatient.DoctorID;
                    
                    
                    txtLabNo.Text = objPatient.LabNo;
                    

                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
        private void BtnOutPatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<OutPatient> objPatients = HMSBal.GetAllOutPatientBAL();
                if (objPatients != null)
                {
                    dgOutPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshOutPatient();

        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }
        public void Clear()
        {
            txtPatientId.Clear();
            txtDate.Text = "";
            txtDoctorId.SelectedValue = -1;
            txtLabNo.SelectedValue = -1;
           
        }
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = HMSBal.GetLabBAL();
                txtLabNo.ItemsSource = labList.DefaultView;
                txtLabNo.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtLabNo.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RefreshOutPatient()
            {
                List<OutPatient> outPatients = null;
            outPatients = HMSBal.GetAllOutPatientBAL();
                if (outPatients.Count > 0)
                {
                    dgOutPatient.DataContext = outPatients;
                }
                else
                {
                    MessageBox.Show("No OutPatient Details available");
                }
            }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
        }
    }
}
