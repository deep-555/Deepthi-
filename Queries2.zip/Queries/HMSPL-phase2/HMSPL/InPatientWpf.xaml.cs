﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSEntity;
using HMSBAL;
using Exceptions;
using System.Data;
namespace HMSPL
{
    /// <summary>
    /// Interaction logic for InPatientWpf.xaml
    /// </summary>
    public partial class InPatientWpf : Window
    {
        HMSBal bal = null;
        public InPatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient patient = new InPatient();
                if (txtPatientId.Text == string.Empty || txtRoomNo.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDate.Text == string.Empty || txtDischargeDate.Text == string.Empty ||
                   txtLabNo.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool InpatientAdded;
                    patient.PatientID = txtPatientId.Text;
                    patient.RoomNo = txtRoomNo.Text;
                    patient.DoctorID = txtDoctorId.Text;
                    patient.AdmissionDate = Convert.ToDateTime(txtDate.Text);
                    patient.DischargeDate = Convert.ToDateTime(txtDischargeDate.Text);
                    patient.LabNo = txtLabNo.Text;
                    patient.Amount = Convert.ToDouble(txtAmount.Text);
                    InpatientAdded = HMSBal.AddInPatientBAL(patient);
                    if (InpatientAdded == true)
                    {
                        MessageBox.Show("InPatient added successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient not added successfully");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient patient = new InPatient();
                if (txtPatientId.Text == string.Empty || txtRoomNo.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDate.Text == string.Empty || txtDischargeDate.Text == string.Empty ||
                                   txtLabNo.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool InpatientUpdated;
                    patient.PatientID = txtPatientId.Text;
                    patient.RoomNo = txtRoomNo.Text;
                    patient.DoctorID = txtDoctorId.Text;
                    patient.AdmissionDate = Convert.ToDateTime(txtDate.Text);
                    patient.DischargeDate = Convert.ToDateTime(txtDischargeDate.Text);
                    patient.LabNo = txtLabNo.Text;
                    patient.Amount = Convert.ToDouble(txtAmount.Text);
                    InpatientUpdated = HMSBal.UpdateInPatientBAL(patient);
                    if (InpatientUpdated == true)
                    {
                        MessageBox.Show("InPatient updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient  could not updated ");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string patientID;
            InPatient patient = new InPatient();
            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientID = txtPatientId.Text;
                    //
                    patientDeleted = HMSBal.DeleteInPatientBAL(patientID);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string PatientId;
                InPatient objPatient;
                PatientId = txtPatientId.Text;
                objPatient = HMSBal.SearchInPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txtRoomNo.Text = objPatient.RoomNo;
                    txtDoctorId.Text = objPatient.DoctorID;
                    txtDate.Text = Convert.ToDateTime(objPatient.AdmissionDate).ToString();
                    txtDischargeDate.Text = Convert.ToDateTime(objPatient.DischargeDate).ToString();
                    txtLabNo.Text = objPatient.LabNo;
                    txtAmount.Text = Convert.ToDouble(objPatient.Amount).ToString();

                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();

        }
        public void Clear()
        {
            txtPatientId.Clear();
            txtRoomNo.SelectedValue=-1;
            txtDoctorId.SelectedValue = -1;
            txtDate.Text = "";
            txtDischargeDate.Text = "";
            txtLabNo.SelectedValue=-1;
            txtAmount.Clear();

        }


    private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

       
        private void BtnInPatient_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                List<InPatient> objPatients = HMSBal.GetAllInPatientBAL();
                if (objPatients != null)
                {
                    dgInPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
            GetRoom();
        }
        
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = HMSBal.GetLabBAL();
                txtLabNo.ItemsSource = labList.DefaultView;
                txtLabNo.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtLabNo.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetRoom()
        {
            try
            {
                DataTable roomList = HMSBal.GetRoomBAL();
                txtRoomNo.ItemsSource = roomList.DefaultView;
                txtRoomNo.DisplayMemberPath = roomList.Columns[0].ColumnName;
                txtRoomNo.SelectedValuePath = roomList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshInPatient();
            
        }
        private void RefreshInPatient()
        {
            List<InPatient> inPatients=null ;
            inPatients = HMSBal.GetAllInPatientBAL();
            if (inPatients.Count > 0)
            {
                dgInPatient.DataContext = inPatients;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }
        }
    }

    }

