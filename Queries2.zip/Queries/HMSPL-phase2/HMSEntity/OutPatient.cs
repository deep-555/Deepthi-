﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntity
{
   public class OutPatient
    {
        public string PatientID { get; set; }
        public DateTime TreatmentDate { get; set; }
        public string  DoctorID { get; set; }
        public string LabNo { get; set; }

    }
}
