﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntity
{
    class PatientAppointment
    {
        public string AppointmentID { get; set; }
        public string PatientID { get; set; }
        public string DoctorName { get; set; }
        public string RoomNumber { get; set; }
        public DateTime DOV { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public string Remarks { get; set; }
    }
}
