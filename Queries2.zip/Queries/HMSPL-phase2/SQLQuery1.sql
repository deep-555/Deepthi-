use Training_19Sep19_Pune
go
create schema [46008916]
create table [46008916].Patient
(
PatientID varchar(10) primary key,
PatientName varchar(20),
Age int,
PatientWeight numeric,
Gender varchar(10),
PAddress varchar(100),
MobileNo varchar(20),
Disease varchar(100),
DoctorID varchar(20) 
);
drop table [46008916].Patient;

create table [46008916].Doctor
(
 DoctorID varchar(20) primary key,
 DoctorName varchar(20),
 Department varchar(20)
 );
 drop table [46008916].Doctor
 create table [46008916].Lab
 (
 LabNo varchar(20) primary key,
 PatientID varchar(10) ,
 DoctorID varchar(20),
 TestDate date,
 TestType varchar(50),
 PatientType varchar(50)
 );
 
  create table [46008916].InPatient
  (
  PatientID varchar(10) primary key,
  RoomNo varchar(20),
  DoctorID varchar(20),
  AdmissionDate date,
  DischargeDate date,
  LabNo varchar(20),
  Amount Real
  );
  drop table [46008916].InPatient

  create table [46008916].OutPatient
  (
  PatientID varchar(10) primary key,
  TreatmentDate date ,
  DoctorID varchar(20),
  LabNo varchar(20)
  );
 
  create table [46008916].RoomData
  (
  RoomNo varchar(20) primary key,
  TreatmentDate date,
  DoctorID varchar(20),
  LabNo varchar(20)
  );
  drop table [46008916].RoomData
  create table [46008916].BillData
  (
  BillNo varchar(20) primary key,
  PatientID varchar(10),
  PatientType varchar(20),
  DoctorID varchar(20),
  DoctorFee Real,
  RoomCharge Real,
  OperationCharges Real,
  MedicineFee Real,
  TotalDays int,
  LabFee Real,
  TotalAmount Real
  );
 
 drop table [46008916].BillData






