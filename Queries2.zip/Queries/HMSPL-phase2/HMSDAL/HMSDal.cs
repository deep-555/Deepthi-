﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HMSEntity;
using Exceptions;

namespace HMSDAL
{
    public class HMSDal
    {
        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].InsertPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", objPatient.Weight);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", objPatient.Address);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Disease);
                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].UpdatePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", objPatient.MobileNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", objPatient.Weight);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", objPatient.Address);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Gender);
                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(string patientID)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].DeletePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

                //
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientbyPatientIDDAL(string PatientId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].SelectPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                //
                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_Weight.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                objSqlParam_PatientID.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.Weight = Convert.ToDouble(objSqlParam_Weight.Value);
                objPatient.Address = objSqlParam_Address.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }


        public Patient SearchPatientbyDoctorIDDAL(string DoctorId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].SelectPatientByDoctor", Con);
                Com.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", SqlDbType.Float);
                SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);

                objSqlParam_PatientID.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Input;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_MobileNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_Weight.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;




                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_MobileNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_Weight);
                Com.Parameters.Add(objSqlParam_Address);
                Com.Parameters.Add(objSqlParam_Disease);


                objSqlParam_DoctorID.Value = DoctorId;

                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.Weight = Convert.ToDouble(objSqlParam_Weight.Value);
                objPatient.Address = objSqlParam_Address.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> Patients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.DoctorID = objDR[8] as string;
                    objPatient.PatientName = objDR[1] as string;
                    objPatient.Gender = objDR[4] as string;
                    objPatient.MobileNo = objDR[6] as string;
                    objPatient.Age = Convert.ToInt32(objDR[2]);
                    objPatient.Weight = Convert.ToDouble(objDR[3]);
                    objPatient.Address = objDR[5] as string;
                    objPatient.Disease = objDR[7] as string;



                    Patients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Patients;
        }


        //**************INPATIENT Information**************


        public bool AddInPatientDAL(InPatient objPatient)
        {
            bool InpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].Insert_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", objPatient.RoomNo);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_AdmissionDate= new SqlParameter("@AdmissionDate", objPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", objPatient.DischargeDate);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);            
                SqlParameter objSqlParam_Amount= new SqlParameter("@Amount", objPatient.Amount);
                
                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);
                

                //
                Con.Open();
                Com.ExecuteNonQuery();
                InpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientAdded;
        }
        public bool UpdateInPatientDAL(InPatient objPatient)
        {
            bool InpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].Update_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", objPatient.RoomNo);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", objPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", objPatient.DischargeDate);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", objPatient.Amount);

                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);


                //
                Con.Open();
                Com.ExecuteNonQuery();
                InpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientUpdated;
        }


        public bool DeleteInPatientDAL(string patientID)
        {
            bool InpatientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].Delete_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

                //
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                InpatientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientDeleted;
        }
        public InPatient SearchInPatientbyPatientIDDAL(string PatientId)
        {
            InPatient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].Select_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", SqlDbType.Date);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", SqlDbType.Date);
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar,20);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", SqlDbType.Real);
                
                //
                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_RoomNo.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;
                objSqlParam_AdmissionDate.Direction = ParameterDirection.Output;
                objSqlParam_DischargeDate.Direction = ParameterDirection.Output;
                objSqlParam_LabNo.Direction = ParameterDirection.Output;
                objSqlParam_Amount.Direction = ParameterDirection.Output;
                



                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorID);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabNo);
                Com.Parameters.Add(objSqlParam_Amount);
               

                //
                objSqlParam_PatientID.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new InPatient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.RoomNo = objSqlParam_RoomNo.Value as string;
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                objPatient.AdmissionDate = Convert.ToDateTime(objSqlParam_AdmissionDate.Value);
                objPatient.DischargeDate = Convert.ToDateTime(objSqlParam_DischargeDate.Value);
                objPatient.LabNo = objSqlParam_LabNo.Value as string;
                objPatient.Amount = Convert.ToDouble(objSqlParam_Amount.Value);
                
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        ////public InPatient SearchInPatientbyDoctorIDDAL(string DoctorId)
        ////{
        ////    InPatient objPatient = null;
        ////    SqlConnection Con = null;
        ////    try
        ////    {
        ////        Con = new SqlConnection(
        ////            ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
        ////        SqlCommand Com = new SqlCommand("[46008916].SelectInPatient", Con);
        ////        Com.CommandType = CommandType.StoredProcedure;
        ////        //
        ////        SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
        ////        SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", SqlDbType.Date);
        ////        SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", SqlDbType.Date);
        ////        SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", SqlDbType.Real);

        ////        //
        ////        objSqlParam_PatientID.Direction = ParameterDirection.Input;
        ////        objSqlParam_RoomNo.Direction = ParameterDirection.Output;
        ////        objSqlParam_DoctorID.Direction = ParameterDirection.Output;
        ////        objSqlParam_AdmissionDate.Direction = ParameterDirection.Output;
        ////        objSqlParam_DischargeDate.Direction = ParameterDirection.Output;
        ////        objSqlParam_LabNo.Direction = ParameterDirection.Output;
        ////        objSqlParam_Amount.Direction = ParameterDirection.Output;




        ////        //
        ////        Com.Parameters.Add(objSqlParam_PatientID);
        ////        Com.Parameters.Add(objSqlParam_RoomNo);
        ////        Com.Parameters.Add(objSqlParam_DoctorID);
        ////        Com.Parameters.Add(objSqlParam_AdmissionDate);
        ////        Com.Parameters.Add(objSqlParam_DischargeDate);
        ////        Com.Parameters.Add(objSqlParam_LabNo);
        ////        Com.Parameters.Add(objSqlParam_Amount);


        ////        //
        ////        objSqlParam_DoctorID.Value = DoctorId;
        ////        //
        ////        Con.Open();
        ////        Com.ExecuteNonQuery();
        ////        objPatient = new InPatient();
        ////        objPatient.PatientID = objSqlParam_PatientID.Value as string;
        ////        objPatient.RoomNo = objSqlParam_RoomNo.Value as string;
        ////        objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
        ////        objPatient.AdmissionDate = Convert.ToDateTime(objSqlParam_AdmissionDate.Value);
        ////        objPatient.DischargeDate = Convert.ToDateTime(objSqlParam_DischargeDate.Value);
        ////        objPatient.LabNo = objSqlParam_LabNo.Value as string;
        ////        objPatient.Amount = Convert.ToDouble(objSqlParam_Amount.Value);

        ////    }
        ////    catch (SqlException objSqlEx)
        ////    {
        ////        throw new HMSException(objSqlEx.Message);
        ////    }
        ////    finally
        ////    {
        ////        Con.Close();
        ////    }
        ////    return objPatient;
        ////}

        public List<InPatient> GetAllInPatientsDAL()
        {
            List<InPatient> InPatients = new List<InPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].ListInPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    InPatient objPatient = new InPatient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.RoomNo = objDR[1] as string;
                    objPatient.DoctorID = objDR[2] as string;
                    objPatient.AdmissionDate = Convert.ToDateTime(objDR[3]);
                    objPatient.DischargeDate= Convert.ToDateTime(objDR[4]);

                    objPatient.LabNo= objDR[5] as string;
                    objPatient.Amount = Convert.ToDouble(objDR[6]);
                    


                    InPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return InPatients;
        }
        


        public DataTable GetDoctorDAL()
        {
            DataTable doctorList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].GetDoctor", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                doctorList = new DataTable();
                doctorList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMSException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return doctorList;
        }
        public DataTable GetLabDAL()
        {
            DataTable labList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].GetLab", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                labList = new DataTable();
                labList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMSException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return labList;
        }

        public DataTable GetRoomDAL()
        {
            DataTable roomList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].GetRoom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                roomList = new DataTable();
                roomList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HMSException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return roomList;
        }

        //*************************OUTPatient Information***********************************************//


        public bool AddOutPatientDAL(OutPatient objPatient)
        {
            bool OutpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].InsertOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@Treatment", objPatient.TreatmentDate);
                
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                
               
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);
                

                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);
                
               
                Com.Parameters.Add(objSqlParam_LabNo);
               


                //
                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientAdded;
        }
        public bool UpdateOutPatientDAL(OutPatient objPatient)
        {
            bool OutpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].UpdateOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", objPatient.PatientID);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@AdmissionDate", objPatient.TreatmentDate);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", objPatient.DoctorID);
                
               
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", objPatient.LabNo);
               

                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);                
                Com.Parameters.Add(objSqlParam_LabNo);
               


                //
                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientUpdated;
        }


        public bool DeleteOutPatientDAL(string patientID)
        {
            bool OutpatientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].DeleteOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", patientID);

                //
                Com.Parameters.Add(objSqlParam_PatientID);

                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientDeleted;
        }
        public OutPatient SearchOutPatientbyPatientIDDAL(string PatientId)
        {
            OutPatient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46008916].SelectOutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", SqlDbType.Date);
                SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);                               
                SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);
               

                //
                objSqlParam_PatientID.Direction = ParameterDirection.Input;
                objSqlParam_TreatmentDate.Direction = ParameterDirection.Output;
                objSqlParam_DoctorID.Direction = ParameterDirection.Output;                
                objSqlParam_LabNo.Direction = ParameterDirection.Output;
                




                //
                Com.Parameters.Add(objSqlParam_PatientID);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorID);
                
                
                Com.Parameters.Add(objSqlParam_LabNo);
                


                //
                objSqlParam_PatientID.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new OutPatient();
                objPatient.PatientID = objSqlParam_PatientID.Value as string;
                objPatient.TreatmentDate = Convert.ToDateTime(objSqlParam_TreatmentDate.Value);
                objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
                
                objPatient.LabNo = objSqlParam_LabNo.Value as string;
                

            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        ////public InPatient SearchInPatientbyDoctorIDDAL(string DoctorId)
        ////{
        ////    InPatient objPatient = null;
        ////    SqlConnection Con = null;
        ////    try
        ////    {
        ////        Con = new SqlConnection(
        ////            ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
        ////        SqlCommand Com = new SqlCommand("[46008916].SelectInPatient", Con);
        ////        Com.CommandType = CommandType.StoredProcedure;
        ////        //
        ////        SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 10);
        ////        SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", SqlDbType.Date);
        ////        SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", SqlDbType.Date);
        ////        SqlParameter objSqlParam_LabNo = new SqlParameter("@LabNo", SqlDbType.VarChar, 20);
        ////        SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", SqlDbType.Real);

        ////        //
        ////        objSqlParam_PatientID.Direction = ParameterDirection.Input;
        ////        objSqlParam_RoomNo.Direction = ParameterDirection.Output;
        ////        objSqlParam_DoctorID.Direction = ParameterDirection.Output;
        ////        objSqlParam_AdmissionDate.Direction = ParameterDirection.Output;
        ////        objSqlParam_DischargeDate.Direction = ParameterDirection.Output;
        ////        objSqlParam_LabNo.Direction = ParameterDirection.Output;
        ////        objSqlParam_Amount.Direction = ParameterDirection.Output;




        ////        //
        ////        Com.Parameters.Add(objSqlParam_PatientID);
        ////        Com.Parameters.Add(objSqlParam_RoomNo);
        ////        Com.Parameters.Add(objSqlParam_DoctorID);
        ////        Com.Parameters.Add(objSqlParam_AdmissionDate);
        ////        Com.Parameters.Add(objSqlParam_DischargeDate);
        ////        Com.Parameters.Add(objSqlParam_LabNo);
        ////        Com.Parameters.Add(objSqlParam_Amount);


        ////        //
        ////        objSqlParam_DoctorID.Value = DoctorId;
        ////        //
        ////        Con.Open();
        ////        Com.ExecuteNonQuery();
        ////        objPatient = new InPatient();
        ////        objPatient.PatientID = objSqlParam_PatientID.Value as string;
        ////        objPatient.RoomNo = objSqlParam_RoomNo.Value as string;
        ////        objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
        ////        objPatient.AdmissionDate = Convert.ToDateTime(objSqlParam_AdmissionDate.Value);
        ////        objPatient.DischargeDate = Convert.ToDateTime(objSqlParam_DischargeDate.Value);
        ////        objPatient.LabNo = objSqlParam_LabNo.Value as string;
        ////        objPatient.Amount = Convert.ToDouble(objSqlParam_Amount.Value);

        ////    }
        ////    catch (SqlException objSqlEx)
        ////    {
        ////        throw new HMSException(objSqlEx.Message);
        ////    }
        ////    finally
        ////    {
        ////        Con.Close();
        ////    }
        ////    return objPatient;
        ////}

        public List<OutPatient> GetAllOutPatientsDAL()
        {
            List<OutPatient> OutPatients = new List<OutPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008916].ListOutPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    OutPatient objPatient = new OutPatient();
                    objPatient.PatientID = objDR[0] as string;
                    objPatient.TreatmentDate = Convert.ToDateTime(objDR[1]);
                    objPatient.DoctorID = objDR[2] as string;
                    
                   

                    objPatient.LabNo = objDR[3] as string;
                  



                    OutPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return OutPatients;
        }



     



    }
}




















        
