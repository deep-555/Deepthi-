﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntity;
using Exceptions;
using System.Text.RegularExpressions;
using System.Data;

namespace HMSBAL
{
    public class HMSBal
    {

        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientID == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            if (patient.DoctorID == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient name is required.");
            }
            else if (!Regex.IsMatch(patient.PatientName, "[A-Z][a-z]"))
            {
                sb.Append("Patient Name must start with a capital letter");
                validPatient = false;
            }
            if (patient.MobileNo.Length < 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
            }
            else if (!Regex.IsMatch(patient.MobileNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validPatient;

        }
        public static bool AddPatientBAL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    HMSDal patientDAL = new HMSDal();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool UpdatePatientBAL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    HMSDal patientDAL = new HMSDal();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBAL(string PatientId)
        {

            bool PatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal patientDAL = new HMSDal();

                    PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid OutPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }

        public static Patient SearchPatientbyPatientIDBAL(string patientId)
        {
            Patient patient = null;

            try
            {
                if (patientId != null)
                {
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchPatientbyPatientIDDAL(patientId);
                }
                else
                {
                    throw new HMSException("Patient Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static Patient SearchPatientbyDoctorIDBAL(string doctorId)
        {
            Patient patient = null;

            try
            {
                if (doctorId != null)
                {
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchPatientbyDoctorIDDAL(doctorId);
                }
                else
                {
                    throw new HMSException("Doctor Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }
        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                HMSDal patient = new HMSDal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

        private static bool ValidateInPatient(InPatient Inpatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            if (Inpatient.PatientID == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            if (Inpatient.RoomNo == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine + "RoomNo  can't be empty.");
            }
            if (Inpatient.DoctorID == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            if (Inpatient.AdmissionDate == null)
            {
                sb.Append(Environment.NewLine + "Admission Date is Required");
                validInPatient = false;
            }
            if (Inpatient.DischargeDate == null)
            {
                sb.Append(Environment.NewLine + "Discharge Date is Required");
                validInPatient = false;
            }
            if (Inpatient.Amount <= 0)
            {
                sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                validInPatient = false;
            }
            if (validInPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validInPatient;
        }


        public static bool AddInPatientBAL(InPatient Inpatient)
        {
            bool InpatientAdded = false;
            try
            {
                if (ValidateInPatient(Inpatient))
                {
                    HMSDal InpatientDAL = new HMSDal();
                    InpatientAdded = InpatientDAL.AddInPatientDAL(Inpatient);
                    return InpatientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientAdded;
        }

        public static bool UpdateInPatientBAL(InPatient Inpatient)
        {
            bool InpatientUpdated = false;
            try
            {
                if (ValidateInPatient(Inpatient))
                {
                    HMSDal InpatientDAL = new HMSDal();
                    InpatientUpdated = InpatientDAL.UpdateInPatientDAL(Inpatient);
                    return InpatientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientUpdated;
        }

        public static bool DeleteInPatientBAL(string PatientId)
        {

            bool InPatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal InpatientDAL = new HMSDal();

                    InPatientDeleted = InpatientDAL.DeleteInPatientDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid InPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InPatientDeleted;
        }

        public static InPatient SearchInPatientbyPatientIDBAL(string patientId)
        {
            InPatient Inpatient = null;

            try
            {
                if (patientId != null)
                {
                    HMSDal InpatientDAL = new HMSDal();
                    Inpatient = InpatientDAL.SearchInPatientbyPatientIDDAL(patientId);
                }
                else
                {
                    throw new HMSException("Patient Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Inpatient;
        }

        //public static InPatient SearchInPatientbyDoctorIDBAL(string doctorId)
        //{
        //    InPatient Inpatient = null;

        //    try
        //    {
        //        if (doctorId != null)
        //        {
        //            HMSDal patientDAL = new HMSDal();
        //            Inpatient = patientDAL.SearchInPatientbyDoctorIDDAL(doctorId);
        //        }
        //        else
        //        {
        //            throw new HMSException("Doctor Id is Required.");
        //        }
        //    }
        //    catch (HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return Inpatient;
        //}
        public static List<InPatient> GetAllInPatientBAL()
        {
            List<InPatient> patientList;
            try
            {
                HMSDal Inpatient = new HMSDal();
                patientList = Inpatient.GetAllInPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

       
        public static DataTable GetDoctorBAL()
        {
            DataTable doctorList;
            try
            {
                HMSDal patientDAL = new HMSDal();
                doctorList = patientDAL.GetDoctorDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return doctorList;
        }
        public static DataTable GetLabBAL()
        {
            DataTable labList;
            try
            {
                HMSDal labDAL = new HMSDal();
                labList = labDAL.GetLabDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }
        public static DataTable GetRoomBAL()
        {
            DataTable roomList;
            try
            {
                HMSDal roomDAL = new HMSDal();
                roomList = roomDAL.GetRoomDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return roomList;
        }



        //**********************OUPPatient Information***********//

        private static bool ValidateOutPatient(OutPatient Outpatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            if (Outpatient.PatientID == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient ID can't  be empty");
            }
            if (Outpatient.TreatmentDate == null)
            {
                sb.Append(Environment.NewLine + "Treatment Date is Required");
                validOutPatient = false;
            }
            if (Outpatient.LabNo == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine + "RoomNo  can't be empty.");
            }
            if (Outpatient.DoctorID == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
                      
           
            if (validOutPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validOutPatient;
        }


        public static bool AddOutPatientBAL(OutPatient Outpatient)
        {
            bool OutpatientAdded = false;
            try
            {
                if (ValidateOutPatient(Outpatient))
                {
                    HMSDal OutpatientDAL = new HMSDal();
                    OutpatientAdded = OutpatientDAL.AddOutPatientDAL(Outpatient);
                    return OutpatientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientAdded;
        }

        public static bool UpdateOutPatientBAL(OutPatient Outpatient)
        {
            bool OutpatientUpdated = false;
            try
            {
                if (ValidateOutPatient(Outpatient))
                {
                    HMSDal InpatientDAL = new HMSDal();
                    OutpatientUpdated = InpatientDAL.UpdateOutPatientDAL(Outpatient);
                    return OutpatientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientUpdated;
        }

        public static bool DeleteOutPatientBAL(string PatientId)
        {

            bool OutPatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal OutpatientDAL = new HMSDal();

                    OutPatientDeleted = OutpatientDAL.DeleteOutPatientDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid OutPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutPatientDeleted;
        }

        public static OutPatient SearchOutPatientbyPatientIDBAL(string patientId)
        {
            OutPatient Inpatient = null;

            try
            {
                if (patientId != null)
                {
                    HMSDal OutpatientDAL = new HMSDal();
                    Inpatient = OutpatientDAL.SearchOutPatientbyPatientIDDAL(patientId);
                }
                else
                {
                    throw new HMSException("Patient Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Inpatient;
        }

        //public static InPatient SearchInPatientbyDoctorIDBAL(string doctorId)
        //{
        //    InPatient Inpatient = null;

        //    try
        //    {
        //        if (doctorId != null)
        //        {
        //            HMSDal patientDAL = new HMSDal();
        //            Inpatient = patientDAL.SearchInPatientbyDoctorIDDAL(doctorId);
        //        }
        //        else
        //        {
        //            throw new HMSException("Doctor Id is Required.");
        //        }
        //    }
        //    catch (HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return Inpatient;
        //}
        public static List<OutPatient> GetAllOutPatientBAL()
        {
            List<OutPatient> patientList;
            try
            {
                HMSDal Inpatient = new HMSDal();
                patientList = Inpatient.GetAllOutPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }


        






    }
}  

